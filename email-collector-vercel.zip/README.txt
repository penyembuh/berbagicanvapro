# Email Collector – Canva Team (Static)
Cara deploy di Vercel:
1) Login ke vercel.com → New Project → Deploy → Upload.
2) Upload ZIP ini apa adanya (jangan ubah struktur).

Isi ZIP:
- index.html  (halaman web statis)
- vercel.json (opsional, untuk clean URLs)

Tidak perlu build command atau output directory.
